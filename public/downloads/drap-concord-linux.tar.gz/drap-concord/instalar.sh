#!/bin/sh
# Instala o DRAP Concord para o usuário atual (sem precisar de administrador).
set -e
cd "$(dirname "$0")"
mkdir -p "$HOME/.local/bin" "$HOME/.local/share/applications" "$HOME/.local/share/icons/hicolor/256x256/apps"
install -m 755 drap-concord "$HOME/.local/bin/drap-concord"
install -m 644 icon-256.png "$HOME/.local/share/icons/hicolor/256x256/apps/drap-concord.png"
sed "s|^Exec=.*|Exec=$HOME/.local/bin/drap-concord|" drap-concord.desktop > "$HOME/.local/share/applications/drap-concord.desktop"
command -v update-desktop-database >/dev/null && update-desktop-database -q "$HOME/.local/share/applications" || true
echo "DRAP Concord instalado. Procure por \"DRAP Concord\" no menu de aplicativos."
